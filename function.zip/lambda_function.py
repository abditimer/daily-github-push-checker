import json
import boto3
from botocore.exceptions import ClientError
import requests
import logging
from datetime import datetime

def lambda_handler(event, context):
    SENDER = "CodePush Reminder <myiahrchatbot@gmail.com>"
    RECIPIENT = "thatimer@gmail.com"
    #The character encoding for the email.
    CHARSET = "UTF-8"
    # Create a new SES resource and specify a region.
    AWS_REGION = "eu-west-2"
    client = boto3.client('ses',region_name=AWS_REGION)
    
    ###############
    todays_date = datetime.today()
    response = requests.get("https://api.github.com/users/abditimer")

    json_payload = response.json()
    last_update = json_payload['updated_at']
    last_update_datetime = datetime.strptime(last_update, '%Y-%m-%dT%H:%M:%SZ')
    if last_update_datetime == todays_date:
        body_str = 'success, no email needed.'
        return {
            'statusCode': 200,
            'body': json.dumps('Email sent!')
        }
    else:
        SUBJECT = 'Dont forget - you need to push!'
        diff_date = todays_date - last_update_datetime
        BODY_TEXT = f'Go code dude! You last pushed {diff_date.days} days ago!'
        try:
            #Provide the contents of the email.
            response = client.send_email(
                Destination={
                    'ToAddresses': [
                        RECIPIENT,
                    ],
                },
                Message={
                    'Body': {
                        'Text': {
                            'Charset': CHARSET,
                            'Data': BODY_TEXT,
                        },
                    },
                    'Subject': {
                        'Charset': CHARSET,
                        'Data': SUBJECT,
                    },
                },
                Source=SENDER,
            )
        # Display an error if something goes wrong.	
        except ClientError as e:
            print(e.response['Error']['Message'])
        else:
            print("Email sent! Message ID:"),
            print(response['MessageId'])